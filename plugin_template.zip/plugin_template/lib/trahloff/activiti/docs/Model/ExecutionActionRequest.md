# ExecutionActionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | **string** |  | [optional] 
**signal_name** | **string** |  | [optional] 
**message_name** | **string** |  | [optional] 
**variables** | [**\Swagger\Client\Model\RestVariable[]**](RestVariable.md) |  | [optional] 
**transient_variables** | [**\Swagger\Client\Model\RestVariable[]**](RestVariable.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


