# FormDataResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**form_key** | **string** |  | [optional] 
**deployment_id** | **string** |  | [optional] 
**process_definition_id** | **string** |  | [optional] 
**process_definition_url** | **string** |  | [optional] 
**task_id** | **string** |  | [optional] 
**task_url** | **string** |  | [optional] 
**form_properties** | [**\Swagger\Client\Model\RestFormProperty[]**](RestFormProperty.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


