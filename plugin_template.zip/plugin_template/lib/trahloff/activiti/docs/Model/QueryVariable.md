# QueryVariable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**operation** | **string** |  | [optional] 
**value** | **object** |  | [optional] 
**type** | **string** |  | [optional] 
**variable_operation** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


