# CommentResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  | [optional] 
**author** | **string** |  | [optional] 
**message** | **string** |  | [optional] 
**time** | [**\DateTime**](\DateTime.md) |  | [optional] 
**task_id** | **string** |  | [optional] 
**task_url** | **string** |  | [optional] 
**process_instance_id** | **string** |  | [optional] 
**process_instance_url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


